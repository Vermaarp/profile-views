# KV Key Schema

All data is stored in Cloudflare KV. Below is the full key schema.

## Key Patterns

| Key Pattern                        | Value Type | TTL       | Description                              |
|------------------------------------|-----------|-----------|------------------------------------------|
| `views:{username}`                 | integer   | permanent | Total all-time view count                |
| `views:{username}:{counter}`       | integer   | permanent | Named counter (per-repo tracking)        |
| `unique:{username}`                | integer   | permanent | Total unique visitor count               |
| `uniq:{username}:{hashedIP}`       | `"1"`     | 24 hours  | Unique visit marker (expires daily)      |
| `daily:{username}:{YYYY-MM-DD}`    | integer   | 7 days    | Views on a specific day                  |
| `rl:{username}:{hashedIP}`         | integer   | 1 hour    | Rate limit counter per IP per username   |
| `__health__`                       | `"1"`     | 10 sec    | Health check sentinel                    |

## Notes

- `{hashedIP}` is a non-reversible integer hash of the client IP (FNV-style), stored as base-36 string
- `{username}` is always lowercased before use
- `{YYYY-MM-DD}` is UTC date (e.g. `2024-07-01`)
- All keys use `:` as the namespace separator

## Storage Estimates (Free Tier)

Cloudflare KV free tier: **1GB storage, 100K reads/day, 1K writes/day**

For 100 active usernames each with 7 days of daily stats:
- `views:*` → ~100 keys × 10 bytes = ~1 KB
- `unique:*` → ~100 keys × 10 bytes = ~1 KB  
- `daily:*` → ~700 keys × 15 bytes = ~10 KB
- `uniq:*` (24h TTL) → ~10K keys × 5 bytes = ~50 KB (auto-expires)
- `rl:*` (1h TTL) → ~500 keys × 3 bytes = ~1.5 KB (auto-expires)

**Total estimated: < 100 KB** — well within free limits.
