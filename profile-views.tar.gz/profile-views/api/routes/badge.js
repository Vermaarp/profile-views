/**
 * Badge route — renders dynamic SVG badges
 */

import { renderSVG } from '../../badge/render.js';
import { isBot } from '../utils/bot-filter.js';
import { checkRateLimit } from '../utils/rate-limit.js';
import { corsHeaders, errorResponse } from '../utils/response.js';

const CACHE_TTL_BOT = 300;   // 5 min for bots/cached
const CACHE_TTL_LIVE = 0;    // no cache for live hits

export async function handleBadge(request, env, ctx) {
  const url = new URL(request.url);
  const params = url.searchParams;

  const username = params.get('user')?.toLowerCase().trim();
  if (!username) return errorResponse(400, 'Missing ?user= param');
  if (!/^[a-z0-9](?:[a-z0-9-]{0,37}[a-z0-9])?$/i.test(username)) {
    return errorResponse(400, 'Invalid GitHub username');
  }

  const options = {
    label: params.get('label') || 'Profile Views',
    color: params.get('color') || '4c8eda',
    style: params.get('style') || 'flat',        // flat | flat-square | plastic | for-the-badge
    theme: params.get('theme') || 'light',       // light | dark | auto
    format: params.get('format') || 'short',     // short | full
    labelColor: params.get('labelColor') || '555',
    logo: params.get('logo') || '',
    type: params.get('type') || 'total',         // total | unique | daily
    counter: params.get('counter') || 'default',
  };

  const userAgent = request.headers.get('User-Agent') || '';
  const bot = isBot(userAgent);

  // Try CF cache first
  const cache = caches.default;
  const cacheKey = new Request(url.toString(), request);

  if (bot) {
    const cached = await cache.match(cacheKey);
    if (cached) return cached;
  }

  // Resolve count
  let count = 0;
  let displayCount = 0;

  if (!bot) {
    const clientIP = request.headers.get('CF-Connecting-IP') || 'unknown';
    const rateLimitKey = `rl:${username}:${hashIP(clientIP)}`;
    const limited = await checkRateLimit(env, rateLimitKey);

    if (!limited) {
      const counterKey = options.counter !== 'default'
        ? `views:${username}:${options.counter}`
        : `views:${username}`;

      count = parseInt(await env.KV.get(counterKey) || '0', 10) + 1;
      ctx.waitUntil(env.KV.put(counterKey, String(count)));

      // Unique tracking
      const uniqueKey = `uniq:${username}:${hashIP(clientIP)}`;
      const isUnique = !(await env.KV.get(uniqueKey));
      if (isUnique) {
        ctx.waitUntil(Promise.all([
          env.KV.put(uniqueKey, '1', { expirationTtl: 86400 }),
          env.KV.get(`unique:${username}`).then(v =>
            env.KV.put(`unique:${username}`, String(parseInt(v || '0', 10) + 1))
          ),
        ]));
      }

      // Daily
      const today = new Date().toISOString().slice(0, 10);
      const dailyKey = `daily:${username}:${today}`;
      ctx.waitUntil(
        env.KV.get(dailyKey).then(v =>
          env.KV.put(dailyKey, String(parseInt(v || '0', 10) + 1), { expirationTtl: 604800 })
        )
      );
    } else {
      count = parseInt(await env.KV.get(`views:${username}`) || '0', 10);
    }
  } else {
    count = parseInt(await env.KV.get(`views:${username}`) || '0', 10);
  }

  // Resolve display value by type
  if (options.type === 'unique') {
    displayCount = parseInt(await env.KV.get(`unique:${username}`) || '0', 10);
  } else if (options.type === 'daily') {
    const today = new Date().toISOString().slice(0, 10);
    displayCount = parseInt(await env.KV.get(`daily:${username}:${today}`) || '0', 10);
  } else {
    displayCount = count;
  }

  const svg = renderSVG(displayCount, options);

  const response = new Response(svg, {
    headers: {
      ...corsHeaders,
      'Content-Type': 'image/svg+xml',
      'Cache-Control': bot
        ? `public, max-age=${CACHE_TTL_BOT}`
        : 'no-cache, no-store, must-revalidate',
      'X-Content-Type-Options': 'nosniff',
      'ETag': `"${username}-${displayCount}"`,
    },
  });

  if (bot) ctx.waitUntil(cache.put(cacheKey, response.clone()));

  return response;
}

function hashIP(ip) {
  let hash = 0;
  for (let i = 0; i < ip.length; i++) {
    hash = ((hash << 5) - hash) + ip.charCodeAt(i);
    hash |= 0;
  }
  return Math.abs(hash).toString(36);
}
