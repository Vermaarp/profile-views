/**
 * Test suite — Vitest
 */

import { describe, it, expect } from 'vitest';
import { isBot } from '../api/utils/bot-filter.js';
import { formatCount, renderSVG } from '../badge/render.js';

// ─── Bot Filter ────────────────────────────────────────────────────────────────

describe('isBot()', () => {
  it('detects Googlebot', () => {
    expect(isBot('Mozilla/5.0 (compatible; Googlebot/2.1; +http://www.google.com/bot.html)')).toBe(true);
  });

  it('detects curl', () => {
    expect(isBot('curl/7.88.1')).toBe(true);
  });

  it('detects empty UA', () => {
    expect(isBot('')).toBe(true);
  });

  it('does NOT flag real Chrome UA', () => {
    expect(isBot('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124.0 Safari/537.36')).toBe(false);
  });

  it('does NOT flag Firefox UA', () => {
    expect(isBot('Mozilla/5.0 (Macintosh; Intel Mac OS X 10.15; rv:125.0) Gecko/20100101 Firefox/125.0')).toBe(false);
  });
});

// ─── Count Formatter ───────────────────────────────────────────────────────────

describe('formatCount()', () => {
  it('formats < 1K as-is', () => {
    expect(formatCount(42, 'short')).toBe('42');
  });

  it('formats 1500 as 1.5K', () => {
    expect(formatCount(1500, 'short')).toBe('1.5K');
  });

  it('formats 1000000 as 1M', () => {
    expect(formatCount(1_000_000, 'short')).toBe('1M');
  });

  it('formats full with no abbreviation', () => {
    expect(formatCount(1234567, 'full')).toContain('1');
  });

  it('strips trailing .0 from K', () => {
    expect(formatCount(2000, 'short')).toBe('2K');
  });
});

// ─── SVG Renderer ──────────────────────────────────────────────────────────────

describe('renderSVG()', () => {
  it('returns a valid SVG string', () => {
    const svg = renderSVG(42, {});
    expect(svg).toContain('<svg');
    expect(svg).toContain('</svg>');
  });

  it('includes the formatted count', () => {
    const svg = renderSVG(1500, { format: 'short' });
    expect(svg).toContain('1.5K');
  });

  it('includes custom label', () => {
    const svg = renderSVG(10, { label: 'Repo Views' });
    expect(svg).toContain('Repo Views');
  });

  it('uses uppercase text for for-the-badge style', () => {
    const svg = renderSVG(10, { style: 'for-the-badge', label: 'views' });
    expect(svg).toContain('VIEWS');
  });

  it('renders flat-square with rx=0', () => {
    const svg = renderSVG(10, { style: 'flat-square' });
    expect(svg).toContain('rx="0"');
  });

  it('includes plastic gradient for plastic style', () => {
    const svg = renderSVG(10, { style: 'plastic' });
    expect(svg).toContain('linearGradient');
  });

  it('handles zero count', () => {
    const svg = renderSVG(0, {});
    expect(svg).toContain('>0<');
  });
});
