/**
 * Bot filtering — heuristic-based, no external calls
 */

const BOT_PATTERNS = [
  /bot/i, /crawler/i, /spider/i, /scraper/i,
  /Googlebot/i, /bingbot/i, /Slurp/i, /DuckDuckBot/i,
  /YandexBot/i, /Baiduspider/i, /facebookexternalhit/i,
  /Twitterbot/i, /rogerbot/i, /LinkedInBot/i,
  /embedly/i, /quora link preview/i, /showyoubot/i,
  /outbrain/i, /pinterest\/0\./i, /developers\.google\.com\/\+\/web\/snippet/i,
  /slackbot/i, /vkShare/i, /W3C_Validator/i,
  /redditbot/i, /Applebot/i, /WhatsApp/i,
  /curl/i, /wget/i, /python-requests/i, /Go-http-client/i,
  /PostmanRuntime/i, /insomnia/i, /httpie/i,
  /axios/i, /node-fetch/i, /got\//i,
];

const SUSPICIOUS_PATTERNS = [
  /^$/,                          // empty UA
  /^-$/,                         // placeholder UA
  /^Mozilla\/5\.0$/,             // bare Mozilla with no details
];

/**
 * Returns true if the User-Agent looks like a bot / automated client
 */
export function isBot(userAgent) {
  if (!userAgent || userAgent.length < 10) return true;

  for (const pattern of SUSPICIOUS_PATTERNS) {
    if (pattern.test(userAgent)) return true;
  }

  for (const pattern of BOT_PATTERNS) {
    if (pattern.test(userAgent)) return true;
  }

  return false;
}
