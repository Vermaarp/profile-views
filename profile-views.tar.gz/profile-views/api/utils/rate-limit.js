/**
 * Simple KV-backed rate limiter
 * Allows N hits per window per key
 */

const WINDOW_SECONDS = 3600; // 1 hour
const MAX_HITS = 5;          // max increments per IP per username per hour

/**
 * Returns true if request should be rate-limited (i.e. over quota)
 */
export async function checkRateLimit(env, key) {
  try {
    const current = parseInt(await env.KV.get(key) || '0', 10);
    if (current >= MAX_HITS) return true;

    await env.KV.put(key, String(current + 1), { expirationTtl: WINDOW_SECONDS });
    return false;
  } catch (_) {
    // If KV fails, allow through (fail open)
    return false;
  }
}
