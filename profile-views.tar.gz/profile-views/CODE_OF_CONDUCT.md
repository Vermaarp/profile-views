# Code of Conduct

## Our Pledge

We pledge to make participation in this project a harassment-free experience for everyone, regardless of age, body size, disability, ethnicity, gender identity, level of experience, nationality, personal appearance, race, religion, or sexual identity.

## Our Standards

**Positive behavior includes:**
- Using welcoming and inclusive language
- Being respectful of differing viewpoints
- Gracefully accepting constructive criticism
- Focusing on what is best for the community

**Unacceptable behavior includes:**
- Harassment, trolling, or insulting comments
- Public or private harassment of any kind
- Publishing others' private information without consent
- Any conduct reasonably considered inappropriate in a professional setting

## Enforcement

Project maintainers may remove, edit, or reject contributions not aligned with this Code of Conduct. Instances of abusive behavior may be reported by opening an issue or contacting a maintainer directly.

## Attribution

This Code of Conduct is adapted from the [Contributor Covenant](https://www.contributor-covenant.org), version 2.1.
