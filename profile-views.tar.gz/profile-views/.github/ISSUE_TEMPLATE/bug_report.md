---
name: Bug Report
about: Something isn't working as expected
title: "[Bug] "
labels: bug
assignees: ''
---

## Describe the bug
A clear description of what the bug is.

## To Reproduce
Steps to reproduce:
1. Badge URL used: `https://...`
2. Expected behavior
3. Actual behavior

## Environment
- Browser / client:
- Cloudflare Workers region (if known):

## Additional context
Paste any error messages or screenshots here.
