---
name: Feature Request
about: Suggest an idea or enhancement
title: "[Feature] "
labels: enhancement
assignees: ''
---

## Problem / motivation
What problem does this feature solve?

## Proposed solution
Describe your idea clearly.

## Alternatives considered
Have you considered other approaches?

## Additional context
Add any context, screenshots, or examples.
