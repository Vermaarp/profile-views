# Badge Usage Examples

Replace `https://your-api.workers.dev` with your deployed URL, and `octocat` with your GitHub username.

---

## Basic embed

```markdown
![Profile Views](https://your-api.workers.dev/badge?user=octocat)
```

---

## Styles

```markdown
<!-- Flat (default) -->
![Views](https://your-api.workers.dev/badge?user=octocat&style=flat)

<!-- Flat Square -->
![Views](https://your-api.workers.dev/badge?user=octocat&style=flat-square)

<!-- Plastic -->
![Views](https://your-api.workers.dev/badge?user=octocat&style=plastic)

<!-- For the Badge -->
![Views](https://your-api.workers.dev/badge?user=octocat&style=for-the-badge)
```

---

## Custom colors

```markdown
<!-- Green value, dark label -->
![Views](https://your-api.workers.dev/badge?user=octocat&color=2ea043&labelColor=333)

<!-- Orange -->
![Views](https://your-api.workers.dev/badge?user=octocat&color=e07b39)
```

---

## Dark theme

```markdown
![Views](https://your-api.workers.dev/badge?user=octocat&theme=dark)
```

---

## Show unique visitors

```markdown
![Unique Visitors](https://your-api.workers.dev/badge?user=octocat&type=unique&label=Unique+Visitors)
```

---

## Show today's views

```markdown
![Today](https://your-api.workers.dev/badge?user=octocat&type=daily&label=Views+Today)
```

---

## Full number format (no abbreviation)

```markdown
![Views](https://your-api.workers.dev/badge?user=octocat&format=full)
```

---

## Per-repo counter

Use the `counter` param to track separate counters per repo:

```markdown
<!-- In repo: my-awesome-project -->
![Repo Views](https://your-api.workers.dev/badge?user=octocat&counter=my-awesome-project&label=Repo+Views)
```

---

## JSON API

Fetch live stats:

```
GET https://your-api.workers.dev/stats?user=octocat&days=7
```

Response:
```json
{
  "user": "octocat",
  "total_views": 4271,
  "unique_visitors": 982,
  "today": 47,
  "this_week": 318,
  "daily": [
    { "date": "2024-01-01", "views": 42 },
    ...
  ]
}
```

---

## HTML embed

```html
<img src="https://your-api.workers.dev/badge?user=octocat&style=flat-square" alt="Profile Views"/>
```
