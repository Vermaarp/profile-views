# Contributing to Profile Views Counter

Thank you for your interest in contributing! 🎉

## Getting Started

1. **Fork** this repository
2. **Clone** your fork: `git clone https://github.com/YOUR_USERNAME/profile-views`
3. **Install** dependencies: `npm install`
4. **Create a branch**: `git checkout -b feat/your-feature`

## Development Setup

```bash
# Install Wrangler CLI globally
npm install -g wrangler

# Authenticate with Cloudflare
wrangler login

# Create KV namespaces
npm run kv:create

# Start local dev server
npm run dev
```

## Code Style

- Run `npm run lint` before committing
- Run `npm run format` to auto-format
- Follow existing patterns in the codebase
- Keep functions small and focused

## Testing

```bash
npm test         # run once
npm run test:watch  # watch mode
```

All new features must include tests in `api/index.test.js`.

## Pull Request Process

1. Make sure `npm test` passes
2. Update `docs/` if adding new query params or endpoints
3. Keep PRs focused — one feature/fix per PR
4. Write a clear PR description explaining what and why

## What to Contribute

Great first issues are labeled `good first issue`. Ideas include:
- New badge styles
- Additional bot detection patterns
- Improved number formatting
- Documentation improvements
- Docker self-host setup improvements

## Code of Conduct

Please read [CODE_OF_CONDUCT.md](CODE_OF_CONDUCT.md) before participating.
